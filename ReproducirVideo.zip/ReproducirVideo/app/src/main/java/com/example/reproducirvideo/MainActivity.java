package com.example.reproducirvideo;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    private VideoView reproductorvideo;

    Button play_pause;
    MediaPlayer mp;
    MediaPlayer vectormp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play_pause = (Button) findViewById(R.id.playmusica);
        vectormp = MediaPlayer.create(this, R.raw.redbone);
        reproductorvideo = findViewById(R.id.vdv_video);

        int orientacion = getResources().getConfiguration().orientation;

        // Referencia para determianr el video que se reproducira en el VideoViw
        reproductorvideo.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.turecuerdo));

        // Controles de Video (Retroceder , Adelantar, Pausa)
        MediaController mc = new MediaController(this);
        reproductorvideo.setMediaController(mc);
        mc.setAnchorView(reproductorvideo);
        reproductorvideo.stopPlayback();
        Button myButton = findViewById(R.id.reproducir);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                reproductorvideo.start();
            }
        });

        Button myButton2 = findViewById(R.id.pausar);
        myButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                reproductorvideo.pause();
            }
        });

        Button myButton3 = findViewById(R.id.playmusica);
        myButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                vectormp.start();
            }
        });

        Button myButton4 = findViewById(R.id.pausemusica);
        myButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                vectormp.pause();
            }
        });

        Button myButton5 = findViewById(R.id.reiniciarmusica);
        myButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    vectormp.seekTo(0);
            }
        });

    }

    public void PlayPause(View view) {
        //if //(vectormp[posicion].isPlaying()) {
            //vectormp[posicion].pause();
            play_pause.setBackgroundResource(R.drawable.reproducir);

        //} else {
            //vectormp[posicion].start();
            //play_pause.setBackgroundResource(R.drawable.pausa);
       // }
    }


}